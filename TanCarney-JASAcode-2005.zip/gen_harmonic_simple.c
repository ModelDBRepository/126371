

void gen_harmonic_simple(float center_f,
                         int slope,
                         double wide,
                         float top_level,
                         char filename[],
                         int n_harmonic/*number of harmonic components*/)
 {
  extern double PI, tdres, *soundin;
  extern int sound_length;
  int n, i, j, k, n1;
  float f0=100.0, /* fundamental frequency*/ f_left, f_right;
  float levelnow;

  FILE *psave01;

  f_left=100* (int)(center_f/100);
  f_right=f_left+100;

  //time_scale=(1:50*250)'*tdres;  %250ms total  % change this if u change tdres
  //soundout=zeros(length(time_scale),1);

  // initialize the input sound
  for (n=1; n<=sound_length; n=n+1)
   {
    soundin[n]=0;
   }

  k=0;
  levelnow=top_level;
  // add center component (if any) and
  // low frequency(lower than center freq) harmonics
  while (levelnow >= top_level - 60)
   {

    k=k+1;

    if ((center_f - wide/2)> f_left)
     {
      levelnow = top_level - log((center_f-wide/2.0)/f_left)/log(2.0)*slope;
     }

    if (k > (n_harmonic+1)/2)
     {
      break;
     }

    if (levelnow < top_level -60)
     {
      break;
     }

    for (n=1; n<=sound_length; n=n+1)
     {
      soundin[n]=soundin[n]+sin(2.0*PI*f_left*n*tdres)*sqrt(2.0)
                            *pow(10.0, (levelnow/20.0))*(2e-5);
     }
    f_left = f_left - 100;
   }

  k=0;
  levelnow=top_level;   // add high frequency(higher than center freq) harmonics
  while (levelnow >= top_level - 60)
   {

    k=k+1;

    if ((center_f + wide/2)< f_right)
     {
      levelnow = top_level - log(f_right/(center_f+wide/2.0))/log(2.0)*slope;
     }

    if (k > (n_harmonic/2) )
     {
      break;
     }

    if (levelnow < top_level -60)
     {
      break;
     }

    for (n=1; n<=sound_length; n=n+1)
     {                                                                                
      soundin[n]=soundin[n]+sin(2*PI*f_right*n*tdres)*sqrt(2.0)
                             *pow(10.0, (levelnow/20.0))*(2e-5);
     }
    f_right = f_right + 100;
   }


  n1= (int)(0.025/tdres);  // %25ms rise/fall time
  for (n=1; n<=n1; n=n+1)
   {
    soundin[n]=soundin[n]*(1-cos(2*PI*20*n*tdres))/2;
   }

  for (n=sound_length-n1; n<=sound_length; n=n+1)
   {
    soundin[n]=soundin[n]*(1-cos(2*PI*20*(n-sound_length+1)*tdres))/2;
   }

  //================= save the sound
  psave01=fopen(filename, "w");
  for (n=1; n<=sound_length; n=n+1)
   {
    fprintf(psave01, "%f  %5.20f\n", n*tdres, soundin[n]);
   }
  fclose(psave01);
}
