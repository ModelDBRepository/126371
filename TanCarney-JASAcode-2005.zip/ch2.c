// cf4 has been removed,.... April 1, 2003

#define SPECTRUM_SHAPE	"tri"  // tri => triangular; tra => trapezoidal
#define SPECTRUM_SLOPE	400  // dB/oct
#define use_simple_signal       0   // 0=> do NOT use simplified signal
												// 1=> use simplified signal

// sound_length is an int now, to be compatible with earlab code
// Nov 20, 2004
//#define sound_length            12500             /* 250ms */

#define MODEL_SIMULATED 1	// 1=> AN3; 2=> ARLO

//#define noglide           1

#include <math.h>
#include <stdio.h>
//#include <alloc.h> // for large memory allocation in BC
#include <malloc.h> // for VC

//#include "/BC5/mysource/basic/an3.h"
#include "anmod3m.h"
#include "gen_harmonic.c"
#include "gen_harmonic_simple.c"

#include "arlo.h"

 // the following sub routines are written at the end of this file
 void generate_cf(
     float f_lo,
     float f_hi,
     int n_cf,
     int in_log ,
     float *pointer_f);


int main()
{
 int i, m, n, n_input, n_cf, total_n;

 // parameters for fiber
 double ta, tb, zero_r,  rgain;
 double nlgain;
 int delayn;
 
 int signal_slope;
 double trapezoid_width;
 int   n_harmonic;               // used for simplified signals
 float f_center;
 float delta_f;
 float f_center_list[]={2000, 2025, 2050, 2075, 2100, 2125, 2150, 2175, 2200};
 //float f_center_list[]={2125, 2150, 2175, 2200};
 float f_lo;
 float f_hi;
 float cfs[501];
 float *pointer_cf;
 float threshold_f;

 //float temp01;
 float temp02;

 double temp_double01, delta_prime, delta_prime_total;

 // filenames
 char harmonic_file[100];
 char response_file[100];
 char information_file[100];
 char threshold_file[100];
 char outputdir[100];
 //char sub_dir01[20];
 //char sub_dir02[20];

 double *sout_a;

 // parameters for rate-information only
 double rate01; // average rate of no delta_f;
 double rate02; // average rate with delta_f;
 double d_prime_rate; // sensitivity of single fiber based on rate;
 double d_prime_rate_total; //total sensitivity of AN population based on rate

 // parameters for ARLO model config
 double ARLO_spont;
 int ARLO_model;
 int ARLO_species;
 int ARLO_ifspike;

 int selected_model; // 1=> AN3 model; 2=> ARLO model

 char signal_shape[4];

 FILE *pread01, *psave01;

 //==========================================
 // important parameters for the signal
 //==========================================
 sound_length = 12500;             /* 250ms */
 
  sprintf(signal_shape, SPECTRUM_SHAPE);
 // 1. triangular spectrum

 if (signal_shape[2] == 'i')
 {
     n_input=5;  //the number of different Fc   (triangular=5, trapezoidal=5 or 9)
             // use 3 if it is simplified signal
     trapezoid_width=0; //0 for triangle and 200Hz for trapezoid
     printf("\nshape=tri \n");
 }
 
// 2. trapezoidal spectrum
 
 if (signal_shape[2] == 'a')
 {
     n_input=5;  //the number of different Fc   (triangular=5, trapezoidal=5 or 9)
             // use 3 if it is simplified signal
     trapezoid_width=200; //0 for triangle and 200Hz for trapezoid
     printf("\nshape=tra \n");
 }
 

 signal_slope= SPECTRUM_SLOPE;
 printf("slope=%d\n", signal_slope);

 delta_f=1.0;


 //=========================================
 // setup for the model fibers
 //=========================================

 // Select a model: 1=> AN3; 2=> ARLO ; MODEL_SIMULATED => as defined
 selected_model = MODEL_SIMULATED;

 // For AN3, control_type = 1 => nonlinear model; 0 => linear sharp model
 control_type=1;

 // allocate memory
 soundin = calloc( sizeof(double), sound_length + 1);
 meout = calloc( sizeof(double), sound_length + 1);
 soundout = calloc(sizeof(double), sound_length + 1);
 control_signal = calloc(sizeof(double), sound_length + 1);
 ihc_out = calloc(sizeof(double), sound_length + 1);
 sout = calloc(sizeof(double), sound_length + 1);
 sout_a = calloc(sizeof(double), sound_length + 1);

 // For ARLO model
 // spont = 50;  // spontaneous rate
 // model = 1; //Nonlinear_w/compression & suppression
 // species = 0; // 0=>human; 9=>cat
 // ifspike = 0;
 ARLO_spont = 50;
 ARLO_model = 1;
 ARLO_species = 0;
 ARLO_ifspike = 0;

 pointer_cf=&cfs[1];
 n_cf=50; //number of channels
 f_lo=1500;   // CF range is from 1500 Hz to 3000 Hz
 f_hi=3000;

 generate_cf(f_lo, f_hi, n_cf, 1, pointer_cf);

 // total number of fibers within the interested frequency range.
 total_n = 30000*(log10(f_hi/f_lo)/log10(20000/20));

 //========================================
 // directory setup
 //========================================
 sprintf(outputdir, ".\\result\\");
 


 //========================================
 // remove the old records
 //========================================
  // remove old threshold files (rate + temporal)
  sprintf(threshold_file,
            "%sthreshold.save.%d.%s.%d",
            outputdir, (signal_slope), signal_shape, n_cf);

 psave01=fopen(threshold_file, "w");
 fclose(psave01);

 // remove old threshold files (rate only)
  sprintf(threshold_file,
           "%sthreshold.rate.%d.%s.%d",
           outputdir, (signal_slope), signal_shape, n_cf);

 psave01=fopen(threshold_file, "w");
 fclose(psave01);

 //========================================
 //  loop of center frequency
 //========================================
 for (m=1; m<=n_input; m=m+1)
 {

  delta_prime_total = 0.0;
  d_prime_rate_total = 0.0;

  //=======================================
  // setup the input signal without delta-f
  //=======================================

    f_center = f_center_list[m-1];
    printf("f_center= %d\n", (int)(f_center));

    sprintf(harmonic_file,
              "%sharmonic.%d.%d.%s.a",
              outputdir, (int)(f_center), (signal_slope), signal_shape);


  if (use_simple_signal ==1)
   {
    // If the simplified signal is used,
    // the number of harmonic components (n_harmonic)
    // is specified here.
    // Right now, only frequency within (1975, 2025), (2025, 2075),
    // and (2075, 2125) is
    // supported. This includes the simulation frequencies described in
    // the paper (2000 and 2050Hz). You can extend the frequency range
    // as you want, but be
    // careful with the number of components needed for your signal.


    if (signal_shape[2]=='i')                                 // triangular
     {
      if (    ((f_center>1975) && (f_center<2025))
           || ((f_center>2075) && (f_center<2125))   )
       {
        n_harmonic = 3;
       }
      if ((f_center>2025) && (f_center<2075))
       {
        n_harmonic = 2;
       }
     }
    else //if (signal_shape[2]...                            // trapezoidal
    {
     if (    ((f_center>1975) && (f_center<2025))
           ||((f_center>2075) && (f_center<2125))   )
      {
       n_harmonic = 5;
      }
     if ((f_center>2025) && (f_center<2075))
      {
       n_harmonic = 4;
      }
    }     //end if (signal_shape[2]...

    gen_harmonic_simple(f_center,   //center frequency of the harmonic complex
                        signal_slope,       //the slope
                        trapezoid_width,    //width of trapezoid
                        40,                 //level of strongest component
                        harmonic_file,
                        n_harmonic );                 //number of components
   }
  else // if  (use_simple_signal ==1)...
   {
    // If use the original signal
    gen_harmonic(f_center, signal_slope,//the slope
                 trapezoid_width,  40, harmonic_file);
   }



  //-------------------------------------
  //  process the signal
  //-------------------------------------

   for (i=1; i<=n_cf; i=i+1)
    {
     cf=cfs[i];


     // ----------------------------
     // The following is for AN3

     if (selected_model == 1)
     {
     		//-------- get all the parameters' values
     		//cf4=cf;
     		setparameter( cf, &fp1, &ta, &tb, &rgain, &nlgain, &zero_r, &delayn);

     		//---------------------------
     		//    get model output

     		middleear();
     		controlpath(nlgain);
     		signalpath(ta, tb, rgain, zero_r);
     		ihczxd2001();                               //
     }

     if (selected_model == 2)
     {
     		//--------------------------------------
     		// Use the following to run ARLO model
     		an_arlo(tdres, (double)cf, ARLO_spont, ARLO_model, ARLO_species,
     				ARLO_ifspike, soundin+1, sout+1, sound_length);
     }


     sprintf(response_file,
             "%sharmonic_response.%d.%d.%d.%s.a",
             outputdir, (int)(f_center), i, (int)(signal_slope), signal_shape);

     psave01=fopen(response_file, "w");

     for (n=1; n<=sound_length; n=n+1)
       {
        fprintf(psave01, "%f  %5.15f \n", n*tdres, sout[n]);
       }
     fclose(psave01);

 	 } // end of i loop

 //==========================================================
 // generate f plus delta-f
 //==========================================================
 f_center = f_center_list[m-1];

 sprintf(harmonic_file,
           "%sharmonic.%d.%d.%s.b",
           outputdir, (int)(f_center), (int)(signal_slope), signal_shape);
  if (use_simple_signal ==1)
   {
    if (signal_shape[2]=='i')                                 // tri signal
     {
      if (    ((f_center>1975) && (f_center<2025))
           || ((f_center>2075) && (f_center<2125))   )
       {
        n_harmonic = 3;
       }
      if ((f_center>2025) && (f_center<2075))
       {
        n_harmonic = 2;
       }
     }
    else //if (signal_shape[2]...                             // tra signal
    {
     if (    ((f_center>1975) && (f_center<2025))
           ||((f_center>2075) && (f_center<2125))   )
      {
       n_harmonic = 5;
      }
     if ((f_center>2025) && (f_center<2075))
      {
       n_harmonic = 4;
      }
    }     //end if (signal_shape[2]...

    gen_harmonic_simple(f_center+delta_f,   //center frequency
                        signal_slope,
                        trapezoid_width,
                        40,
                        harmonic_file,
                        n_harmonic );
   }
  else // if  (use_simple_signal ==1)...
   {
    gen_harmonic(f_center+delta_f, signal_slope,
                 trapezoid_width,  40, harmonic_file);
   }

 //-------------------------------------
 // remove old sensitivity files
 //-------------------------------------

    // old sensitivity file (rate + timing)
    sprintf(information_file,
               "%ssensitivity.%d.%d.%s",
               outputdir, (int)(f_center), (int)(signal_slope), signal_shape);

     psave01=fopen(information_file, "w");
     fclose(psave01);

    // remove old sensitivity files (rate only)
    sprintf(information_file,
              "%ssensitivity.rate.%d.%d.%s",
              outputdir, (int)(f_center), (int)(signal_slope), signal_shape);

    psave01=fopen(information_file, "w");
    fclose(psave01);

 //-------------------------------------
 //  process the signal with delta_f
 //-------------------------------------

  for (i=1; i<=n_cf; i=i+1)
   {
    cf=cfs[i];

    if (selected_model == 1)
    {
    		//-------- get all the parameters' values
    		//cf4=cf;
    		setparameter( cf, &fp1, &ta, &tb, &rgain, &nlgain, &zero_r, &delayn);

    		//---------------------------
    		//    get model output
    		middleear();
    		controlpath(nlgain);
    		signalpath(ta, tb, rgain, zero_r);
    		ihczxd2001();
    }

    if (selected_model == 2)
    {
     		// -------------------------------
     		// The following is for ARLO model
         an_arlo(tdres, (double)cf, ARLO_spont, ARLO_model, ARLO_species,
     				ARLO_ifspike, soundin+1, sout+1, sound_length);
    }

    sprintf(response_file,
             "%sharmonic_response.%d.%d.%d.%s.b",
             outputdir, (int)(f_center), i, (int)(signal_slope), signal_shape);

   psave01=fopen(response_file, "w");

   for (n=1; n<=sound_length; n=n+1)
     {
      fprintf(psave01, "%f  %5.15f \n", n*tdres, sout[n]);
     }
    fclose(psave01);


   //=================================================
   // load the response without delta-f
   //=================================================


   sprintf(response_file,
             "%sharmonic_response.%d.%d.%d.%s.a",
             outputdir, (int)(f_center), i, (int)(signal_slope), signal_shape);

   pread01=fopen(response_file, "r");

    for (n=1; n<=sound_length; n=n+1)
     {
      if (fscanf(pread01, "%f", &temp02)==EOF)
       {
stay01:   temp02=0.0;      //If something is wrong in reading file,
									// it will stay here. Or, you can specify what
                           // you want to do.
       goto stay01;
       }
      fscanf(pread01, "%f", &temp02);
      sout_a[n]=temp02;
     }
    fclose(pread01);

   //=================================================
   // compute the sensitivity
   //=================================================

   //initialization
   delta_prime=0.0;
   sprintf(information_file,
             "%ssensitivity.%d.%d.%s",
             outputdir, (int)(f_center), (int)(signal_slope), signal_shape);

   psave01=fopen(information_file, "a");

   for (n=1; n<=sound_length; n=n+1)
    {
     temp_double01 = (sout[n]-sout_a[n])/delta_f;
     temp_double01 = temp_double01 * temp_double01 / (sout[n] + 0.01) * tdres;

     delta_prime = delta_prime + temp_double01;
    }

   // save sensitivity of each fiber
   fprintf(psave01, "%f   %8.20f \n", cf, delta_prime);
   fclose(psave01);

   delta_prime_total = delta_prime_total + delta_prime;

   //-----------------------------------
   // use average rate information only
   rate01=0.0;
   rate02=0.0;
   for (n=1; n<=sound_length; n=n+1)
    {
     rate01 = rate01 + sout[n];
     rate02 = rate02 + sout_a[n];
    }
   rate01 = rate01*tdres;
   rate02 = rate02*tdres;
   d_prime_rate=(rate01-rate02)*(rate01-rate02)/delta_f/delta_f/(rate01+0.01);
   d_prime_rate_total=d_prime_rate_total + d_prime_rate;
   // save average rate sensitivity for each fiber
   sprintf(information_file,
             "%ssensitivity.rate.%d.%d.%s",
             outputdir, (int)(f_center), (int)(signal_slope), signal_shape);

   psave01=fopen(information_file, "a");
   fprintf(psave01, "%f  %8.20f \n", cf, d_prime_rate);
   fclose(psave01);

  } // end of i loop


  //-------------------------------------------------------------------
  // get threshold (rate + timing)
  threshold_f=1.0/sqrt(delta_prime_total * total_n / n_cf);
  // save threshold
   sprintf(threshold_file,
             "%sthreshold.save.%d.%s.%d",
             outputdir, (int)(signal_slope), signal_shape, n_cf);

  psave01=fopen(threshold_file, "a");

  fprintf(psave01, "%f   %5.20f \n", f_center, threshold_f);
  fclose(psave01);

  //-------------------------------------------------------------------
  //save sensitivity and threshold based on rate information only
  threshold_f=1.0/sqrt(d_prime_rate_total * total_n / n_cf);
   sprintf(threshold_file,
             "%sthreshold.rate.%d.%s.%d",
             outputdir, (int)(signal_slope), signal_shape, n_cf);

  psave01=fopen(threshold_file, "a");

  fprintf(psave01, "%f   %5.20f \n", f_center, threshold_f);
  fclose(psave01);

 } // end of m loop

 return 0;
} // end of WinMain  //change to main sept 20, 2001


//============================================================
//
//      sub routines
//
//============================================================

 void generate_cf(float f_lo, float f_hi, int n_cf, int in_log, float *pointer_f)
 {
  int n;

  float space_factor;
  //char filename[100];
  //FILE *psave01;

  // In the published version, the CF list is not saved.
  //sprintf(filename, "c:\\bc5\\mysource\\crbound\\cf_list.%d.%d.%d.txt",
  //                                   n_cf, i, j);

  //psave01=fopen(filename, "w");

  if (n_cf==1) // in case n_cf==1
   {
    *pointer_f=f_lo;
    return;
   }

  space_factor =exp(log(f_hi/f_lo)/(n_cf - 1));
  for (n=1; n<=n_cf; n=n+1)
   {
    *pointer_f = f_lo *pow(space_factor, (n-1));
    pointer_f = pointer_f + 1;
    //fprintf(psave01, "%f\n", f_lo * pow(space_factor, (n-1)) );
   }
  //fclose(psave01);
  return ;

 }








