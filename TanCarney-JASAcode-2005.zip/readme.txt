
C code for the simulations as described in Tan and Carney (JASA 2005)

//==============================================================
How to compile and run the files:

(1) In Microsoft Visual C++ (tested in Version 7.1.3088 and 6.0)
   1. Extract all files to a desired directory 
   2. Create an empty Win32 console project in this directory
   3. Add ch2.c in the Source Files section (Make sure that this is
      the only file in the Source Files list in the project window)
   4. Create a sub-directory with name result. 
      All simulation outputs will be written in this sub-directory
   5. Build and run
   
(2) In Borland C (tested in Version 5.02)
   1. Extract all files to a desired directory
   2. Create an empty project in this directory.
      Set platform to Win32 and Target Model to console.
   3. If a few .cpp, .def, or .rc files are automatically selected into
      this project, please remove them from the project's file list.
   4. Select ch2.c as the only file in the project's file list
   5. Create a sub-directory with name result. 
      All simulation outputs will be written in this sub-directory
   6. Build and run

//==============================================================
How to modify the settings in the simulations:

   Most settings can be modified in ch2.c. 
   For example:
   1. In line 3, set SPECTRUM_SHAPE to "tri" for triangular spectrum and
      "tra" for trapezoidal spectrum
   2. In line 4, set SPECTRUM_SLOPE to desired spectrum slope 
      (100, 200, or 400)
   3. In line 12, set MODEL_SIMULATED to 1 for Tan & Carney (JASA 2003)
      model or set it to 2 for the model in Heinz et al. (ARLO 2001)

//===============================================================
How to read the results (thresholds)
    After each run, you will get output files named 
    threshold.save.$$$.***.50 for predictions based on both rate and timing
    and threshold.rate.$$$.***.50 for predictions based on rate only.
    $$$ refers to the spectral slope (100, 200, or 400)
    *** refers to the spectral shape (tri or tra)
    In each file, the first column is the center frequency and the second
    column is the threshold.
    
Thanks for your interest in our simulations. Any suggestions/comments
will be appreciated!

Enjoy!