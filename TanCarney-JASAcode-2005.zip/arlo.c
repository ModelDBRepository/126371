// arlo.c
//
// Aug 28, 2004
// Created by Qing Tan as a testbase for ZXD's ARLO model

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/*
#include "cmpa.h"
#include "complex.h"
#include "filters.h"
#include "hc.h"
#include "runmodel.h"
//#include "spikes.h"
#include "synapse.h"


#include "cmpa.c"
#include "complex.c"
#include "filters.c"
*/
#include "c:\bc5\mysource\crbound\arlo\arlo.h"

/*
#include "hc.c"
#include "runmodel.c"
#include "filters.c"
#include "synapse.c"
#include "complex.c"
#include "cmpa.c"     */


void main()
{
		int error;
      double *para,*in,*out;
      double tdres,cf,spont;
      int model;
      int species;
      int ifspike;
      double  x;
      int     length,mrows,ncols;

      int n, m;

      FILE *fid;

      // Model parameters
		tdres = 2e-5;
      cf = 1000;
      spont = 50;
      model = 1;
      species = 0;
      ifspike = 0;

      // Input signal
      length = 1000;
      in = calloc(sizeof(double), length);

      *(in+1)=1;

      // Output
      out = calloc(sizeof(double), length);

      /*  Call the C subroutine. */
      error = an_arlo(tdres,cf,spont,model,species,ifspike,in,out,length);

      fid = fopen("output.txt", "w");
      for (n=0; n<length; n++)
      {
      	fprintf(fid, "%f \n", *(out+n));
      }
      fclose(fid);
}
